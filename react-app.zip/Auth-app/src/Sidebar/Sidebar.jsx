import React from 'react';
import './Sidebar.scss';
const Sidebar = () => {
  return (
    <div className='sidebar'>Sidebar</div>
  )
}

export default Sidebar;