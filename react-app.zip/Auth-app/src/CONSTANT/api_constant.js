export const BASEURL = 'http://my-blog.space';


// export const BASEURL = 'http : //react-api';
